<?php if(!$isindex) :?>
<div class="di_dhk huis_12">
<div class="zuo"><table border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="bottom">所在位置：</td>
    <td width="20" valign="bottom"><a href="index.html"><img src="/images/di_dh_shouye.jpg"/></a></td>
    <td valign="bottom"><a href="/index.php">首页</a> > <?php echo $conname ;?> > <?php echo $actname ;?></td>
  </tr>
</table>
</div>
<div class="you"><a href="#top"><img src="/images/di_dh_zhiding.jpg"/></a></div>
<?php endif ;?>