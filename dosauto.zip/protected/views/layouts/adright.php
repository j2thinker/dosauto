<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>后台管理 </title>
<script type="text/javascript" src="/kindeditor/kindeditor-min.js"></script>
<style type="text/css">
#maincon{
	width:100% ;
	margin:0 auto ;
	height:auto!important;
    height:580px;
    min-height:580px;
	border:2px solid #EEEEEE ;
}
.nav{
	width:100% ;
	height:30px;
	background-color:#f5f5f5;
	border-bottom:1px solid #EFEFEF;
	float:left ;
	text-align:left ;
	padding-top:10px;
}

.list{
	clear:both ;
	width:100% ;
	margin-top:10px;
	border:1xp solid #FE0000 ;
}

table{
	margin-top:50px;
	border-collapse:collapse;
	border:2px solid #d3d3d3;
	text-align:center;
	font-family:"微软雅黑","宋体";
	font-size:12px;
}

.con {
	clear:both ;
	float：left ;
	width:90%;
	margin:0 auto ;
}
</style>
</head>
<body>
	<div id="maincon">
		<?php echo $content; ?>
	</div>
</body>
</html>