<div class="dingtuk"><img src="/images/xw_ding_tu.jpg"/></div>
<div class="gs_btk">
<div class="zuo"><img src="/images/xw_bt_zhongxin.jpg"/></div>
<div class="you">
<table border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><img src="/images/fd_kf1.jpg" onmouseover="this.src='/images/fd_kf2.jpg'" onmouseout="this.src='/images/fd_kf1.jpg'"/></td>
    <td>&nbsp;</td>
    <td><a href="gc_jisuanqi.html"><img src="/images/fd_jsq1.jpg" onmouseover="this.src='/images/fd_jsq2.jpg'" onmouseout="this.src='/images/fd_jsq1.jpg'"/></a></td>
    <td>&nbsp;</td>
    <td><a href="sh_shijia.html"><img src="/images/fd_sj1.jpg" onmouseover="this.src='/images/fd_sj2.jpg'" onmouseout="this.src='/images/fd_sj1.jpg'"/></a></td>
    <td>&nbsp;</td>
    <td><a href="gc_yuding.html"><img src="/images/fd_yd1.jpg" onmouseover="this.src='/images/fd_yd2.jpg'" onmouseout="this.src='/images/fd_yd1.jpg'"/></a></td>
  </tr>
</table>

</div>
</div>

<div class="gs_lbk hei_12">
<ul>
<li class="dqli">最新活动</li>
<li><a href="xw_cuxiao.html">优惠促销</a></li>
<li><a href="xw_gongsi.html">公司新闻</a></li>
<li><a href="xw_hangye.html">行业新闻</a></li>
<li><a href="xw_fuwu.html">衍生服务</a></li>
<li><a href="xw_tuangou.html">团购消息</a></li>
<li class="hli"><a href="xw_baoyang.html">保养讲堂</a></li>
</ul>
</div>


<div class="xw_xqk hui_12 hangg2">
<div class="xw_btk">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="87%" height="40" class="hei_16">LEXUS雷克萨斯名列2012年J.D. Power中国新车质量研究SM（IQS）报告榜首</td>
    <td width="13%" rowspan="2" align="right"><a href="xw_huodong.html"><img src="/images/xw_an_fanhui.jpg" width="96" height="23" /></a></td>
  </tr>
  <tr>
    <td height="20" class="huis_12">2012年11月7日，北京</td>
    </tr>
</table>


</div>
<div class="xw_nrk">J.D. Power亚太公司近日发布了2012年中国新车质量研究SM（IQS）报告，LEXUS雷克萨斯从所有研究涉及的品牌中脱颖而出，荣登榜首。新车质量的综合得分以每百辆车的问题数（PP100）来衡量，分数越低表明问题发生率越低，质量也越高。这一成绩的取得证明了LEXUS雷克萨斯对&quot;矢志不渝，追求完美&quot;这一品牌理念的不懈追求。<br />
   <br />
  中国新车质量研究（IQS）是J.D. Power亚太公司在消费者反馈的基础上进行的基准研究之一。J.D. Power亚太公司已经在中国开展此项研究超过13年，这项研究衡量新车车主购车后2-6 个月内经历的问题，并将新车质量问题明确划分为设计问题以及产品缺陷和故障两类。研究报告分析了12个细分市场，一共涵盖68个品牌的215款车型。数据采集工作于2012年4月至8月在中国43个主要城市进行。<br />
   <br />
  一直以来，LEXUS雷克萨斯对产品质量秉持严苛的专注态度，追求完美，力求以卓越的设计、领先的科技以及顶尖的工艺为客户带来超越期待的品质选择，获得了全球消费者满意的微笑。目前LEXUS雷克萨斯已在中国市场推出了13大系列的17款车型，其中包括5款全混动车型。这些车型均因其卓越的产品品质、激情的驾驭体验及舒适的驾乘感受，受到了国内消费者的广泛赞誉和喜爱。<br />
   <br />
  在不断超越客户期待的同时，LEXUS雷克萨斯也努力通过人性化的服务，为消费者提供尊崇的驾乘生活。在中国市场，LEXUS雷克萨斯率先推出4年/10万公里的免费保修及免费保养服务，于2007年推出了油电混合动力车型6年/15万公里的免费保修及免费保养服务，2012年，随着全新一代ES的上市，LEXUS雷克萨斯又针对ES 300h混合动力车型推出了10年/25万公里的无忧承诺。此外，LEXUS雷克萨斯的零配件24小时配送、全年24小时道路救援、LEXUS雷克萨斯专项保险、LEXUS G-BOOK雷克萨斯智能副驾等多项汽车行业领先的人性化服务，为每一位车主提供全程无忧的尊崇用车体验。通过提供最精良品质的豪华汽车及超越顾客期待的服务才能取得今天的殊荣，赢得消费者最大程度的满意与信赖，这也是LEXUS雷克萨斯在不断追求完美道路上的动力源泉。 </div>
</div>


<div class="di_dhk huis_12">
<div class="zuo"><table border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="bottom">所在位置：</td>
    <td width="20" valign="bottom"><a href="index.html"><img src="/images/di_dh_shouye.jpg"/></a></td>
    <td valign="bottom"><a href="index.html">首页</a> > 新闻中心 > 最新活动</td>
  </tr>
</table>
</div>
<div class="you"><a href="#top"><img src="/images/di_dh_zhiding.jpg"/></a></div>