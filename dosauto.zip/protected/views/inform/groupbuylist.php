<div class="dingtuk"><img src="/images/xw_ding_tu.jpg"/></div>

<?php $this->widget("InfonavWidget") ;?>

<div class="xw_tgk hui_12 hangg2">
<ul>

<li><a href="javascript:void(0)"><img src="/images/xw_tgtu.jpg"/></a><br />
<a href="javascript:void(0)"><img src="/images/xw_tgan_kankan.jpg" class="animg"/></a>
</li>

<li><a href="javascript:void(0)"><img src="/images/xw_tgtu.jpg"/></a><br />
<a href="javascript:void(0)"><img src="/images/xw_tgan_kankan.jpg" class="animg"/></a>
</li>

</ul>
<div class="zuo ym_k hei_12">

<span><a href="javascript:void(0)"><</a></span>
<span class=" dqspan"><a href="javascript:void(0)">1</a></span>
<span><a href="javascript:void(0)">2</a></span>
<span><a href="javascript:void(0)">3</a></span>
<span><a href="javascript:void(0)">4</a></span>
<span><a href="javascript:void(0)">></a></span>

</div>
<div class="qingchu"></div>
</div>