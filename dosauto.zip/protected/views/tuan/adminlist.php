<div class="nav">
	<div style="width:90%;float:left;font-size:14px ;">&nbsp;&nbsp;&nbsp;&nbsp;<b>团购列表</b></div>
	<div style="width:9%;float:left;font-size:14px ;" >
		<a href="/index.php/tuan/add" target="_self">添加团购信息</a>
	</div>
</div>
<div class="con">
	<table border="1" width="98%" style="margin-top:20px ;" cellpadding=10 cellspacing=0>
		<tr>
			<td width="10%">团购ID</td>
			<td width="50%">团购图片</td>
			<td width="30%">链接地址</td>
			<td width="10%">操作</td>
		</tr>
		<tr>
			<td>团购ID</td>
			<td>团购图片</td>
			<td>链接地址</td>
			<td>操作</td>
		</tr>
	</table>
</div>