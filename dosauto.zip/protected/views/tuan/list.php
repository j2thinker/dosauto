<div class="dingtuk"><img src="/images/xw_ding_tu.jpg"/></div>


<div class="gs_btk">
<div class="zuo"><img src="/images/xw_bt_zhongxin.jpg"/></div>
<div class="you">
<table border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><img src="/images/fd_kf1.jpg" onmouseover="this.src='/images/fd_kf2.jpg'" onmouseout="this.src='/images/fd_kf1.jpg'"/></td>
    <td>&nbsp;</td>
    <td><a href="gc_jisuanqi.html"><img src="/images/fd_jsq1.jpg" onmouseover="this.src='/images/fd_jsq2.jpg'" onmouseout="this.src='/images/fd_jsq1.jpg'"/></a></td>
    <td>&nbsp;</td>
    <td><a href="sh_shijia.html"><img src="/images/fd_sj1.jpg" onmouseover="this.src='/images/fd_sj2.jpg'" onmouseout="this.src='/images/fd_sj1.jpg'"/></a></td>
    <td>&nbsp;</td>
    <td><a href="gc_yuding.html"><img src="/images/fd_yd1.jpg" onmouseover="this.src='/images/fd_yd2.jpg'" onmouseout="this.src='/images/fd_yd1.jpg'"/></a></td>
  </tr>
</table>

</div>
</div>

<div class="gs_lbk hei_12">
<?php $this->widget("InfonavWidget") ;?>
</div>


<div class="xw_tgk hui_12 hangg2">
<ul>

<li><a href="javascript:void(0)"><img src="/images/xw_tgtu.jpg"/></a><br />
<a href="javascript:void(0)"><img src="/images/xw_tgan_kankan.jpg" class="animg"/></a>
</li>

<li><a href="javascript:void(0)"><img src="/images/xw_tgtu.jpg"/></a><br />
<a href="javascript:void(0)"><img src="/images/xw_tgan_kankan.jpg" class="animg"/></a>
</li>

</ul>
<div class="zuo ym_k hei_12">

<span><a href="javascript:void(0)"><</a></span>
<span class=" dqspan"><a href="javascript:void(0)">1</a></span>
<span><a href="javascript:void(0)">2</a></span>
<span><a href="javascript:void(0)">3</a></span>
<span><a href="javascript:void(0)">4</a></span>
<span><a href="javascript:void(0)">></a></span>

</div>
<div class="qingchu"></div>
</div>

<div class="di_dhk huis_12">
<div class="zuo"><table border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="bottom">所在位置：</td>
    <td width="20" valign="bottom"><a href="index.html"><img src="/images/di_dh_shouye.jpg"/></a></td>
    <td valign="bottom"><a href="index.html">首页</a> > 新闻中心 > 团购消息</td>
  </tr>
</table>
</div>
<div class="you"><a href="#top"><img src="/images/di_dh_zhiding.jpg"/></a></div>