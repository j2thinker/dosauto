<div class="nav">
	<div style="width:90%;float:left;font-size:14px ;">&nbsp;&nbsp;&nbsp;&nbsp;<b>添加团购信息</b></div>
</div>
<div class="con">
	<form method="post" action="">
	<table border="1" width="98%" style="margin-top:20px ;" cellpadding=10 cellspacing=0>
		<tr>
			<td>团购图片</td>
			<td  align="left">
				<input type="file" name="pic_url" />
			</td>
		</tr>
		<tr>
			<td>链接地址</td>
			<td  align="left">
				<input type="text" name="tuan_url" />
			</td>
		</tr>
		<tr>
			<td colspan="2" align="center">
				<input type="submit" value="确认添加" /> <input type="button" value="返回上一页" onclick="javascript:history.go(-1);" />
			</td>
		</tr>
	</table>
	</form>
</div>