<div class="dingtuk"><img src="tupian/gs_ding_tu.jpg"></div>
<div class="gs_btk">
<div class="zuo"><img src="tupian/gs_bt_jieshao.jpg"></div>
<div class="you">
<table border="0" cellpadding="0" cellspacing="0">
  <tbody><tr>
    <td><img src="tupian/fd_kf1.jpg" onmouseover="this.src='tupian/fd_kf2.jpg'" onmouseout="this.src='tupian/fd_kf1.jpg'"></td>
    <td>&nbsp;</td>
    <td><a href="gc_jisuanqi.html"><img src="tupian/fd_jsq1.jpg" onmouseover="this.src='tupian/fd_jsq2.jpg'" onmouseout="this.src='tupian/fd_jsq1.jpg'"></a></td>
    <td>&nbsp;</td>
    <td><a href="sh_shijia.html"><img src="tupian/fd_sj1.jpg" onmouseover="this.src='tupian/fd_sj2.jpg'" onmouseout="this.src='tupian/fd_sj1.jpg'"></a></td>
    <td>&nbsp;</td>
    <td><a href="gc_yuding.html"><img src="tupian/fd_yd1.jpg" onmouseover="this.src='tupian/fd_yd2.jpg'" onmouseout="this.src='tupian/fd_yd1.jpg'"></a></td>
  </tr>
</tbody></table>

</div>
</div>

<div class="gs_lbk hei_12">
<ul>
<?php if($id == 1):?>
<li class="dqli">公司简介</li>
<?php else:?>
<li><a href="/index.php/site/intro/1">公司简介</a></li>
<?php endif;?>

<?php if($id == 2):?>
<li class="dqli">品牌历史</li>
<?php else:?>
<li><a href="/index.php/site/intro/2">品牌历史</a></li>
<?php endif;?>

<?php if($id == 3):?>
<li class="dqli">销售团队</li>
<?php else:?>
<li><a href="/index.php/site/intro/3">销售团队</a></li>
<?php endif;?>

<?php if($id == 4):?>
<li class="dqli">联系我们</li>
<?php else:?>
<li><a href="/index.php/site/intro/4">联系我们</a></li>
<?php endif;?>

<?php if($id == 5):?>
<li class="hli dqli">加入我们</li>
<?php else:?>
<li class="hli"><a href="/index.php/site/joinus">加入我们</a></li>
<?php endif;?>

</ul>
</div>

<div class="gs_zhutik hui_12 hangg2">
<?php echo $content;?>
<div class=" qingchu"></div>
</div>

<div class="di_dhk huis_12">
<div class="zuo"><table border="0" cellpadding="0" cellspacing="0">
  <tbody><tr>
    <td valign="bottom">所在位置：</td>
    <td valign="bottom" width="20"><a href="index.php"><img src="tupian/di_dh_shouye.jpg"></a></td>
    <td valign="bottom"><a href="index.php">首页</a> &gt; <a href="/index.php/site/intro/1">公司介绍</a> &gt; <?php echo $navigation;?></td>
  </tr>
</tbody></table>
</div>
<div class="you"><a href="#top"><img src="tupian/di_dh_zhiding.jpg"></a></div>
<div class=" qingchu"></div>
</div>



