<?php
echo "abc" ;